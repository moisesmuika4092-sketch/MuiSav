-- MuiSav: colar no Supabase > SQL Editor e executar uma vez.
create table perfis(
  id uuid primary key references auth.users on delete cascade,
  nome text,
  papel text not null default 'colaborador'
);
create table registos(
  k text primary key,
  owner uuid not null default auth.uid() references auth.users on delete cascade,
  col text not null,
  data jsonb not null,
  atualizado timestamptz default now()
);
create index on registos(owner);

create function public.sou_admin() returns boolean
language sql security definer set search_path=public stable as
$$ select exists(select 1 from perfis where id=auth.uid() and papel='admin') $$;

create function public.novo_utilizador() returns trigger
language plpgsql security definer set search_path=public as
$$ begin
  insert into perfis(id,nome) values(new.id, coalesce(new.raw_user_meta_data->>'nome', new.email));
  return new;
end $$;
create trigger ao_criar after insert on auth.users
for each row execute function public.novo_utilizador();

alter table perfis enable row level security;
alter table registos enable row level security;

create policy perfis_ler on perfis for select using (id=auth.uid() or sou_admin());
create policy reg_ler on registos for select using (owner=auth.uid() or sou_admin());
create policy reg_ins on registos for insert with check (owner=auth.uid());
create policy reg_upd on registos for update using (owner=auth.uid()) with check (owner=auth.uid());
create policy reg_upd_admin on registos for update using (public.sou_admin()) with check (public.sou_admin());
create policy reg_del on registos for delete using (owner=auth.uid());

insert into storage.buckets(id,name,public) values('docs','docs',false);
create policy docs_ins on storage.objects for insert to authenticated
  with check (bucket_id='docs' and (storage.foldername(name))[1]=auth.uid()::text);
create policy docs_ler on storage.objects for select to authenticated
  using (bucket_id='docs' and ((storage.foldername(name))[1]=auth.uid()::text or public.sou_admin()));

-- Depois de criares o teu utilizador (Authentication > Users), torna-te administrador:
-- update perfis set papel='admin' where id=(select id from auth.users where email='O_TEU_EMAIL');
